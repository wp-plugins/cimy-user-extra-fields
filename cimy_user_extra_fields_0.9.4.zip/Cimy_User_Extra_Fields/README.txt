Cimy User Extra Fields

WordPress is becoming more than ever a tool to open blog/websites and CMSs in an easier way. Users are increasing day by day; one of the limits however is the restricted and predefined fields that are available in the registered users profile: it is difficult for example to ask for the acceptance of "Terms and Conditions of Use" or "Permission to use personal data".
It's also possible to set a password during registration combined to equalTO rule, only people who knows the password can register.

We have developed a WordPress plug-in to do this.

There are some plug-ins that do something similar, but this one wants to focus on giving the administrator the possibility to add all fields needed, on the rules that can be defined for each field, and in giving the possibility to both administration and the user to change the data inserted.

The plug-in adds two new menu voices in the admin for the administrator and two for users.

Two new menus are:

    * "Users-> A&U Extended" lets you show users lists with the new fields that are created
    * "Options-> Cimy User Extra Fields" lets administrators add as many new fields as are needed to the users' profile, giving the possibility to set some interesting rules.

Rules are:

    * min/exact/max length admitted (only for text, textarea and password fields)
    * field needed (only for text, textarea and password fields)
    * check for e-mail address syntax (only for text, textarea and password fields)
    * field can be modified after the registration
    * field equal to some value (for example accept terms and conditions)
      * equal to can be or not case sensitive (only case insensitive for checkbox and radio fields)
    * field can be hidden during registration
    * field can be hidden in user's profile
    * field can be hidden in A&U Extended page

New fields will be visible in the profile and in the registration.
As for now the plug-in supports: text, textarea, password, checkbox, radio and drop-down fields, future versions can have more.

Bugs or suggestions can be mailed at: cimmino.marco@gmail.com

REQUIREMENTS:
PHP >= 4.3.0
WORDPRESS >= 2.1.x
MYSQL >= 4.0


INSTALLATION:
- just copy whole Cimy_user_extra_fields subdir into your plug-in directory and activate it

UPDATE FROM A PREVIOUS VERSION:
- always deactivate the plug-in and reactivate after the update


FUNCTIONS USEFUL FOR YOUR THEMES OR TEMPLATES:

[Function get_cimyFieldValue]
NOTE 1: to use this function first you have to enable it via options page.
NOTE 2: password fields values will not be returned for security reasons

This function is all you need to retrieve extra fields values, but in order to retrieve all power from it you have to understand all different ways that can be used.


CASE 1:
get an extra field value from a specific user

PARAMETERS: pass user_id as first parameter and field_name as second
RETURNED VALUE: the function will return a string containing the value

GENERIC:
	$value = get_cimyFieldValue(<user_id>, <field_name>);
EXAMPLE:
	$value = get_cimyFieldValue(1, 'MY_FIELD');


CASE 2:
get all extra fields values from a specific user

PARAMETERS: pass user_id as first parameter and a boolean set to false as second
RETURNED VALUE: the function will return an associative array containing all extra fields values from that user

GENERIC:
	$values = get_cimyFieldValue(<user_id>, false);
EXAMPLE:
	$values = get_cimyFieldValue(1, false);

	foreach ($values as $value) {
		echo $value['NAME'];
		echo $value['VALUE'];
	}


CASE 3:
get value from a specific extra field and from all users

PARAMETERS: pass a boolean set to false as first parameter and field_name as second
RETURNED VALUE: the function will return an associative array containing the specific extra field value from all users

GENERIC:
	$values = get_cimyFieldValue(false, <field_name>);
EXAMPLE:
	$values = get_cimyFieldValue(false, 'MY_FIELD');

	foreach ($values as $value) {
		echo $value['user_login'];
		echo $value['VALUE'];
	}


CASE 4:
get all users that have a specific value in a specific extra field

PARAMETERS: pass a boolean set to false as first parameter, field_name as second and field_value as third
RETURNED VALUE: the function will return an associative array containing all users that has that value in that specific extra field

GENERIC:
	$values = get_cimyFieldValue(false, <field_name>, <field_value>);
EXAMPLE:
	$values = get_cimyFieldValue(false, 'COLOR', 'red');

	foreach ($values as $value) {
		echo $value['user_login'];
	}


USAGE:
$value = get_cimyFieldValue($user_id, $field_name, [$field_value]);

In ALL cases if an error is occured or there are no matching results from the call then NULL is returned.

ADDITIONAL EXAMPLES:

This is an entire example that can be used into your theme for example to retrieve the value from SITE extra field that of course was created
If you put the example just inside an existing loop you shouldn't add it again, just use get_cimyFieldValue call and echo call.

if (have_posts()) {
	while (have_posts()) {
		the_post();

		$value = get_cimyFieldValue(get_the_author_ID(), 'SITE');

		if ($value != NULL)
			echo $value;
	}
}


If you experience duplicate printing this is due to the loop and where/how it is used; to avoid this you can use this code that has a little workaround.
REMEMBER: you cannot use get_the_author_ID() outside the loop, this because WordPress doesn't permit this.

if (have_posts()) {
	$flag = true;

	while (have_posts()) {
		the_post();

		if ($flag) {
			$value = get_cimyFieldValue(get_the_author_ID(), 'SITE');

			if ($value != NULL)
				echo $value;

			$flag = false;
		}
	}
}


[Function get_cimyFields]
This function returns an array containing all extra fields defined by the admin ordered by the order defined in the option page, if there are no fields an empty array is returned.

USAGE:
$allFields = get_cimyFields();

EXAMPLE:
$allFields = get_cimyFields();

if (count($allFields) > 0) {
	foreach ($allFields as $field) {
		echo "ID: ".$field['ID']." \n";
		echo "F_ORDER: ".$field['F_ORDER']." \n";
		echo "NAME: ".$field['NAME']." \n";
		echo "TYPE: ".$field['TYPE']." \n";
		echo "VALUE: ".$field['VALUE']." \n";
		echo "LABEL: ".$field['LABEL']." \n";
		echo "DESCRIPTION: ".$field['DESCRIPTION']." \n";

		echo "RULES: ";
		print_r($field['RULES']);
		echo "\n\n";
	}
}


KNOWN BUGS/BEHAVIORS:
- plug-in never deletes automatically its own tables, to do this uncomment the row "add_action('deactivate_...);" and deactivate the plug-in (deletes all and only data created by the plug-in itself)
- if you add too many fields in the "A&U Extended" menu they will go out of frame
- if you add too many fields in the registration form you will go out of frame, but in this particular case it's a WordPress limitation; to workaround this you have to modify yourself file [wordpress dir]/wp-admin/images/login-bkg-tile.gif extending its height (by default is only 700 pixels) or you can use one provided by me in the package with these height: 1000, 1500, 2000 or 5000 pixels note that if height is bigger than necessary it's automatically cut, so probably choosing the bigger one is the right solution
- some rules are applied only during registration (apart editable and visibility rules and max length for text and password fields only)


FAQ:
Q: Cimy User Extra Fields is not compatible with "Themed Login", how can I do?

A: The reality is this plug-in IS compatible with WordPress 2.1 or greater and "Themed Login" NOT, so it's NOT a Cimy User Extra Field's bug! However I have tried with a little success a workaround to make it works, but first please understand that this is totally untested and unsupported hack, if you want a better one ask the author of that plug-in to support new WordPress!
If you still want *my* personal and unsupported hack edit the plug-in "Themed Login" and at line 871 (just before "A password will be emailed to you.") add this:
<?php do_action('register_form'); ?>


Q: get_cimyFieldValue function doesn't work, why?

A: From v0.9.1 I have added a security option to disable that function. If you don't really use it then avoid to enable it, this is because this function can be hacked to retrieve all personal data inserted by subscribers in all extra fields.
Enable and use this function only if extra fields does not contains personal informations.


Q: When feature XYZ will be added?

A: I don't know, remember that this is a 100% free project so answer is "When I have time to..." visit the homepage and read the news, if there are no new news then back another day :)


Q: Can I hack this plug-in and hope to see my code in the next release?

A: For sure, this is just happened and can happen again if you write useful new features and good code. Try to see how I maintain the code and try to do the same (or even better of course), I have rules on how I write it, don't want "spaghetti code", I'm italian and I want spaghetti only on my plate.
There is no guarantee that your patch will reach Cimy User Extra Fields, but feel free to do a fork of this project and distribuite it, this is GPL!


CHANGELOG:
v0.9.4 - 25/06/2007
- Added a checkbox to manage equalTO rule and make it case sensitive or not
- Rewritten get_cimyFieldValue function:
  - now can accept also only one parameter: FIELD_NAME or USER_ID
  - added a third optional parameter called FIELD_VALUE
  - never return values from password fields for security reasons
  - updated README file to reflect changes to this function
  - note that this new version is backward compatible with previous calls
- Fixed equalTO rule that worked only if text was written in upper case
- Fixed equalTO error message for drop-down fields included also all choices and not only real label
- Fixed all HTML code, now it's XHTML 1.0 Transitional compliant
- Code cleanup

v0.9.3 - 10/06/2007
- Added min length and exact length rules
- Code cleanup

v0.9.2 - 06/06/2007
- Fixed radio and checkbox fields were too large under Internet Explorer 6.0 or lower, I know I have said that I will never fix this, but I lied!
- Removed warning and relative option for MSIE 6.0 (or lower) users introduced in 0.9.1
- Removed in user's profile border and grey background in radio and checkbox fields that were visible in some browsers like: Opera and Internet Explorer
- Fixed fields order, was totally broken for newer MYSQL versions (at least in mine 5.0.38, now should be ok for every one)
- Added a check that shows a warning in the options page when an user has updated the plug-in but forgot to de-activate and re-activate it

v0.9.1 - 05/06/2007
- Added Options page:
  - enable/disable get_cimyFieldValue() function to avoid unwanted use of this function by third parties
  - show/not a warning in the user's profile for who uses Microsoft Internet Explorer 6.0 or lower
  - add titles to fieldset
  - choose how many extra fields to show per one fieldset
  - hide/show some columns in "A&U Extended" page
- User's profile is now reorganized: checkbox and radio fields are back into fieldset; due to a WordPress CSS I made a workaround to avoid bigger inputs, however this workaround doesn't work under Microsoft Internet Explorer 6.0 or lower, this will never be fixed so don't ask about it!
- Do not include php_compat_mqgpc_unescape() function if already included by some other plug-in
- Code cleanup

v0.9.0 final - 15/05/2007
- Added some checks to make plug-in more secure and avoid admin functions to be used by non-admin (more security patches with next releases)
- Fixed own profile saved twice
- Re-added subdir in the package, removed by a mistake in 0.9.0-rc2
- Some Readme changes

v0.9.0 release candidate 2 - 15/04/2007
- Added extra fields data deletions when a user is deleted
- Added a lot of checks for string length inserted by user
- Added max length rule also to textarea field
- Changed max length up to 5000 characters for: value, label and description
- Changed "value" and "label" fields to textarea in the admin menu

v0.9.0 release candidate 1 - 01/04/2007
- Added drop-down support thanx to Raymond Elferink that hacked my plug-in, I have made only some small enhancements to his code
- Added a rule to set/unset field visibility in User's profile page
- Added a rule to set/unset field visibility in "A&U Extended" page
- Changed the way rules are saved, with php serialize seems a better way for code maintainability
- Label can now have length up to 1024 characters
- Updated get_cimyFields example in README file
- Fixed a bug that prevents changing options to a field with special characters in the name
- Some cosmetic changes to A&U Extended page
- Emulate magic_quotes_gpc=off if they are turned on
- Database changes: added indexes in both tables, if you have a lot of data probably this will increase speed
- Database changes: changed field 'LABEL' to TEXT in wp_cimy_fields table
- Code cleanup

v0.9.0 beta8 - 23/03/2007
- Finally fixed the very boring bug that for some people plug-in never creates tables when activated! Thanx to ysjack for helping me reproduce the problem
- Dropped using $table_prefix variable since WordPress 2.1 deprecated it
- Updated get_cimyFieldValue example in README file, now it is a complete example
- Added a subdir in the package

v0.9.0 beta7 - 17/03/2007
- Added password support, now you can set a password to register to your site!
- Added stripslashes also to get_cimyFieldValue function so no more backslashes are returned with certain characters
- Fixed get_cimyFieldValue function never returns NULL when some parameter was wrong, now it does!

v0.9.0 beta6 - 16/03/2007
- Fixed value field wasn't applied in user's profile when a text or textarea was empty
- Fixed a bug (introduced in beta5) that fill some data in the new field form when you just update an existing field
- Fixed editable rule that was broken probably in beta3 or 4 during some code cleanup :(
- Changed plug-in link, now it points to the specific blog page

v0.9.0 beta5 - 15/03/2007
- Added textarea support (up to 1024 characters)
- Added class attribute in the registration form so now all extra fields have the same look like built-in ones
- Added tabindex attribute in the registration form so now when you press tab you have a normal sequence
- Now in the option page when you fill the form for a new field all data are kept in memory every time you press "Add" button
- Fixed equalTO rule for text fields that any value entered was to be all in upper case format to make error message go away
- Code cleanup

v0.9.0 beta4 - 13/03/2007 later
- Forgot to change also tables creation with new modification made in beta3, if you had problem please update to this version and activate the plug-in again, all will back to normal
- Performance improvement: now extra fields are read from database only when they are needed
- Added get_cimyFields() function to retrieve all extra fields information useful for templates/themes
- Fixed equalTO rule in radio fields, was completely broken
- Code cleanup

v0.9.0 beta3 - 13/03/2007
- Added radio input support
- Added value field, you can now pre-enter characters in your text fields or pre-select checkbox and radio fields
- Added a check that disable all rules unrelated to a certain field type
- Added some login-bkg-tile.gif with bigger height to workaround fields out of frame during registration
- Fixed checkbox fields in edit profile were very large, to fix this all radio and checkbox fields are now out of fieldset
- Some cosmetic changes to option and profile pages
- All html transformable characters are now transformed in UTF-8 html format
- Added a stripslashes before showing data so these characters are now allowed: ', ", <, >, (, ), [, ], #
- Database changes: new field 'VALUE', changed fields 'RULES' and 'DESCRIPTION' to TEXT in wp_cimy_fields table
- Database changes: changed field 'VALUE' to TEXT in wp_cimy_data table
- Code cleanup

v0.9.0 beta2
- Fixed a bug that returns MYSQL error when deleting extra fields in certain circumstances
- Fixed a bug that returns MYSQL errors in Users->Your Profile and when adding a new user from administration, these errors were shown only when there were no extra fields defined
- Added a control to prevent from creating/deleting tables to users without enough privileges

v0.9.0 beta1
- Plug-in now supports only WordPress 2.1!
- Removed wp-register.php, with WP 2.1 is not needed anymore, form registration extra fields are now built-in
- Added get_cimyFieldValue function that can be used in your themes
- Fixed a bug that prevents to save unchecked checkbox in user's profile
- Fixed a bug that returns MYSQL error during user's profile update and all fields were set to "Cannot be edited"
- Moved all these infos to a readme file

v0.8.7
- Fixed a bug with PHP<5.0 that in the "equalTo" field saves some strange characters

v0.8.6
- First public release