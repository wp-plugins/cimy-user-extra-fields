<?php
/*
Plugin Name: Cimy User Extra Fields
Plugin URI: http://www.cimatti.it/blog/2007/02/12/cimy-user-extra-fields-for-wordpress-21/
Plugin Description: Add some useful fields to registration and user's info
Version: 0.9.4
Author: Marco Cimmino
Author URI: mailto:cimmino.marco@gmail.com
*/

/*

Cimy User Extra Fields - Allows adding mySQL Data fields to store/add more user info
Copyright (c) 2006, 2007 Marco Cimmino

Code for drop-down support is in part from Raymond Elferink raymond@raycom.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.


The full copy of the GNU General Public License is available here: http://www.gnu.org/licenses/gpl.txt

*/

if (!function_exists(php_compat_mqgpc_unescape))
	include_once("magic_quotes_gpc_off_function.php");

$wpdb_data_table = $wpdb->prefix."cimy_data";
$wpdb_fields_table = $wpdb->prefix."cimy_fields";

$cimy_uef_options = "cimy_uef_options";
$cimy_uef_options_descr = "Cimy User Extra Fields options are stored here and modified only by admin";

/*

RULES (stored into an associative array and serialized):
- 'min_length':		[int]		=> specify min length [only for text, textarea and password]
- 'exact_length':	[int]		=> specify exact length [only for text, textarea and password]
- 'max_length':		[int]		=> specify max length [only for text, textarea and password]
- 'email':		[true | false]	=> check or not for email syntax [only for text, textarea and password]
- 'can_be_empty':	[true | false]	=> field can or cannot be empty [only for text, textarea and password]
- 'edit':		['ok_edit' | edit_only_if_empty' | 'no_edit'] => field can be modified | field can be modified only in the registration or if it's still empty | field cannot be modified [only for text, textarea and password]
- 'equal_to':		[string] => field should be equal to a specify string
- 'equal_to_case_sensitive': [true | false] => equal_to if selected can be case sensitive or not
- 'show_in_reg':	[true | false]	=> field is visible or not in the registration
- 'show_in_profile':	[true | false]	=> field is visible or not in user's profile
- 'show_in_aeu':	[true | false]	=> field is visible or not in A&U Extended page

TYPE can be:
- 'text'
- 'textarea'
- 'password'
- 'checkbox'
- 'radio'
- 'dropdown'

*/

$cuef_plugin_dir = dirname(__FILE__);
$cuef_plugin_name = basename(__FILE__);
$cuef_plugin_path_pos = strpos($cuef_plugin_dir, "plugins");
$cuef_plugin_path = substr($cuef_plugin_dir, $cuef_plugin_path_pos + 8);
		
if ($cuef_plugin_path == FALSE)
	$cuef_plugin_path = "";
else if ($cuef_plugin_path != "")
	$cuef_plugin_path.= "/";
	
$cimy_uef_name = "Cimy User Extra Fields";
$cimy_uef_version = "0.9.4";
$cimy_uef_url = "http://www.cimatti.it/blog/2007/02/12/cimy-user-extra-fields-for-wordpress-21/";

$start_cimy_uef_comment = "<!--\n";
$start_cimy_uef_comment .= "\tStart code from ".$cimy_uef_name." ".$cimy_uef_version."\n";
$start_cimy_uef_comment .= "\tCopyright (c) 2006, 2007 Marco Cimmino\n";
$start_cimy_uef_comment .= "\thttp://www.cimatti.it/blog/2007/02/12/cimy-user-extra-fields-for-wordpress-21/\n";
$start_cimy_uef_comment .= "-->\n";

$end_cimy_uef_comment = "\n<!--\n";
$end_cimy_uef_comment .= "\tEnd of code from ".$cimy_uef_name."\n";
$end_cimy_uef_comment .= "-->\n";

// this array means: create a new row in the admin table AFTER position # (ex. if 2 means AFTER #2)
$admin_menu_new_row = array(8);

// strong illegal charset
$strong_illegal_chars = "/(\%27)|(\/)|(\\\)|(\[)|(\])|(\')|(\")|(\<)|(\>)|(\-\-)|(\%23)|(\#)/ix";

// light illegal charset
$light_illegal_chars = "/(\%27)|(\/)|(\\\)|(\[)|(\])|(\-\-)|(\%23)|(\#)/ix";

$available_types = array("text", "textarea", "password", "checkbox", "radio", "dropdown");
$rule_canbeempty = array("text", "textarea", "password");

// common for min, exact and max length
$rule_maxlen = array("text", "password", "textarea");

// common for min, exact and max length
$rule_maxlen_needed = array("text", "password");

$rule_email = array("text", "textarea", "password");
$rule_profile_value = array("text", "textarea", "password");

$rule_equalto_case_sensitive = array("text", "textarea", "password", "dropdown");

$max_length_name = 20;
$max_length_label = 5000;
$max_length_desc = 5000;
$max_length_value = 5000;
$max_length_fieldset_value = 1024;

$fields_name_prefix = "cimy_uef_";

// add checks for extra fields in the registration form
add_action('register_post', 'cimy_registration_check');

// add extra fields to registration form
add_action('register_form', 'cimy_registration_form');

// add extra fields to user's profile
add_action('show_user_profile', 'cimy_extract_ExtraFields');

// add extra fields in users edit profiles (for ADMIN)
add_action('edit_user_profile', 'cimy_extract_ExtraFields');

// this hook is no more used since the one below is enough for all
//add_action('personal_options_update', 'cimy_update_ExtraFields');

// add update engine for extra fields to users edit profiles
add_action('profile_update', 'cimy_update_ExtraFields');

// function that is executed during activation of the plug-in
add_action('activate_'.$cuef_plugin_path.$cuef_plugin_name,'cimy_plugin_install');

// function that is executed during de-activation of the plug-in
//add_action('deactivate_'.$cuef_plugin_path.$cuef_plugin_name,'cimy_plugin_uninstall');

// add update engine for extra fields to user's registration
add_action('user_register', 'cimy_register_user_extra_fields');

// function that add the submenu under 'Users'
add_action('admin_menu', 'cimy_admin_menu_custom');

// delete user extra fields data when a user is deleted
add_action('delete_user', 'cimy_delete_user_info');

function cimy_delete_user_info($user_id) {
	global $wpdb, $wpdb_data_table;
	
	if (!current_user_can('edit_user', $user_id))
		return;
	
	$sql = "DELETE FROM ".$wpdb_data_table." WHERE USER_ID=".$user_id;
	$wpdb->query($sql);
}

function cimy_dropDownOptions($values, $selected) {
	
	$label_pos = strpos($values, "/");
	
	if ($label_pos) {
		$label = substr($values, 0, $label_pos);
		$values = substr($values, $label_pos + 1);
	}
	else
		$label = "";
	
	$items = explode(",",$values);
	$html_options = "";
	
	foreach ($items as $item) {
		$html_options.= "\n\t\t\t";
		$html_options.= '<option value="'.$item.'"';
	
		if  (isset($selected))
			if ($selected == $item)
				$html_options.= ' selected="selected"';

		$html_options.= ">".$item."</option>";
	}
	
	$ret = array();
	$ret['html'] = $html_options;
	$ret['label'] = $label;
	
	return $ret;
}

function get_cimyFields() {

	global $wpdb_fields_table, $wpdb;

	// if tables exist then read all fields else array empty, will be read after the creation
	if($wpdb->get_var("show tables like '$wpdb_fields_table'") == $wpdb_fields_table) {
		$sql = "SELECT * FROM ".$wpdb_fields_table." ORDER BY F_ORDER";
		$extra_fields = $wpdb->get_results($sql, ARRAY_A);
	
		if (!isset($extra_fields))
			$extra_fields = array();
		else {
			for ($i = 0; $i < count($extra_fields); $i++) {
				$extra_fields[$i]['RULES'] = unserialize($extra_fields[$i]['RULES']);
			}
			
			$extra_fields = stripslashes_deep($extra_fields);
		}
	}
	else
		$extra_fields = array();

	return $extra_fields;
}

function cimy_admin_menu_custom() {
	global $cimy_uef_name;
	
	add_options_page($cimy_uef_name, $cimy_uef_name, 10, basename(__FILE__), 'cimy_admin_define_extra_fields');
        add_submenu_page('profile.php', 'Authors & Users Extended', 'A&amp;U Extended', 10, basename(__FILE__), 'cimy_admin_users_list_page');
}

function cimy_register_user_extra_fields($user_id) {
	global $wpdb_data_table, $wpdb, $max_length_value, $fields_name_prefix;

	include("magic_quotes_gpc_off.php");
	
	$extra_fields = get_cimyFields();

	foreach ($extra_fields as $thisField) {

		$type = $thisField["TYPE"];
		$name = $thisField["NAME"];
		$field_id = $thisField["ID"];
		$label = $thisField["LABEL"];
		$rules = $thisField["RULES"];

		if (isset($_POST[$fields_name_prefix.$name]))
			$data = stripslashes($_POST[$fields_name_prefix.$name]);

		if (isset($rules['max_length']))
			$data = substr($data, 0, $rules['max_length']);
		else
			$data = substr($data, 0, $max_length_value);
		
		$data = mysql_real_escape_string(htmlentities($data, ENT_QUOTES, "UTF-8"));

		$sql = "INSERT INTO ".$wpdb_data_table." SET USER_ID = ".$user_id.", FIELD_ID=".$field_id.", ";

		switch ($type) {
			case 'textarea':
			case 'dropdown':
			case 'password':
			case 'text':
				$field_value = $data;
				break;

			case 'checkbox':
				$field_value = $data == '1' ? "YES" : "NO";
				break;

			case 'radio':
				$field_value = $data == $field_id ? "selected" : "";
				break;
		}

		$sql.= "VALUE='".$field_value."'";

		$wpdb->query($sql);
	}
}

function cimy_registration_check() {
	global $errors, $rule_canbeempty, $rule_email, $rule_maxlen, $fields_name_prefix, $rule_equalto_case_sensitive;

	include("magic_quotes_gpc_off.php");
	
	$extra_fields = get_cimyFields();

	foreach ($extra_fields as $thisField) {

		$field_id = $thisField['ID'];
		$name = $thisField['NAME'];
		$rules = $thisField['RULES'];
		$type = $thisField['TYPE'];
		$label = $thisField['LABEL'];
		$description = $thisField['DESCRIPTION'];
		
		if (isset($_POST[$fields_name_prefix.$name]))
			$value = stripslashes($_POST[$fields_name_prefix.$name]);

		if ($type == "dropdown") {
			$ret = cimy_dropDownOptions($label, $value);
			$label = $ret['label'];
			$html = $ret['html'];
		}

		// if flag to view also in the registration is activated
		if ($rules['show_in_reg']) {

			switch ($type) {
				case 'checkbox':
					$value == 1 ? $value = "YES" : $value = "NO";
					break;
				case 'radio':
					intval($value) == intval($field_id) ? $value = "YES" : $value = "NO";
					break;
			}

			// if the flag can be empty is NOT set OR the field is not empty then other check can be useful, otherwise skip all
			if ((!$rules['can_be_empty']) || ($value != "")) {
				if (($rules['email']) && (in_array($type, $rule_email))) {
					if (!is_email($value))
						$errors['checkemail'.$name] = __('<strong>ERROR</strong>: '.$label.' hasn&#8217;t a correct email syntax.');
				}
		
				if ((!$rules['can_be_empty']) && (in_array($type, $rule_canbeempty))) {
					if ($value == '')
						$errors['empty'.$name] = __('<strong>ERROR</strong>: '.$label.' couldn&#8217;t be empty.');
				}
		
				if (isset($rules['equal_to'])) {
					
					$equalTo = $rules['equal_to'];
					
					if ((!in_array($type, $rule_equalto_case_sensitive)) || (!$rules['equal_to_case_sensitive'])) {
						
						$value = strtoupper($value);
						$equalTo = strtoupper($equalTo);
					}

					if ($value != $equalTo) {
						
						if ($type == "password")
							$equalmsg = " isn't correct";
						else
							$equalmsg = ' should be '.$equalTo;
						
						$errors['equalto'.$name.$field_id] = __('<strong>ERROR</strong>: '.$label.$equalmsg.'.');
					}
				}
				
				// MIN LEN
				if (isset($rules['min_length'])) {
					$minlen = intval($rules['min_length']);

					if (strlen($value) < $minlen) {
						
						$errors['minlength'.$name] = __('<strong>ERROR</strong>: '.$label.' couldn&#8217;t have length less than '.$minlen.'.');
					}
				}
				
				// EXACT LEN
				if (isset($rules['exact_length'])) {
					$exactlen = intval($rules['exact_length']);

					if (strlen($value) != $exactlen) {
						
						$errors['exactlength'.$name] = __('<strong>ERROR</strong>: '.$label.' couldn&#8217;t have length different than '.$exactlen.'.');
					}
				}
				
				// MAX LEN
				if (isset($rules['max_length'])) {
					$maxlen = intval($rules['max_length']);

					if (strlen($value) > $maxlen) {
						
						$errors['maxlength'.$name] = __('<strong>ERROR</strong>: '.$label.' couldn&#8217;t have length more than '.$maxlen.'.');
					}
				}
			}
		}
	}
}

function cimy_registration_form() {
	global $start_cimy_uef_comment, $end_cimy_uef_comment, $rule_maxlen_needed, $fields_name_prefix;

	include("magic_quotes_gpc_off.php");
	
	$extra_fields = get_cimyFields();
	$tabindex = 21;

	echo $start_cimy_uef_comment;
	echo "\t";
	echo '<input type="hidden" name="cimy_post" value="1" />';
	echo "\n";

	$radio_checked = array();

	foreach ($extra_fields as $thisField) {

		$field_id = $thisField['ID'];
		$name = $thisField['NAME'];
		$rules = $thisField['RULES'];
		$type = $thisField['TYPE'];
		$label = $thisField['LABEL'];
		$description = $thisField['DESCRIPTION'];
		$maxlen = 0;

		if (isset($_POST[$fields_name_prefix.$name]))
			$value = stripslashes($_POST[$fields_name_prefix.$name]);
		else if (!isset($_POST["cimy_post"])) {
			$value = $thisField['VALUE'];

			switch($type) {

				case "radio":
					if ($value == "YES")
						$value = $field_id;
					else
						$value = "";
					
					break;
	
				case "checkbox":
					if ($value == "YES")
						$value = "1";
					else
						$value = "";
					
					break;
			}
		}
		else
			$value = "";

		// if flag to view also in the registration is activated
		if ($rules['show_in_reg']) {

			if ($description != "") {
				echo "\t";
				echo '<p class="desc"><br />'.$description.'</p>';
				echo "\n";
			}
	
			echo "\t<p>\n\t";

			switch($type) {
				case 'password':
				case "text":
					$obj_label = '<label for="'.$fields_name_prefix.$field_id.'">'.$label.'</label><br />';
					$obj_class = ' class="input"';
					$obj_name = ' name="'.$fields_name_prefix.$name.'"';
					$obj_type = ' type="'.$type.'"';
					$obj_value = ' value="'.$value.'"';
					$obj_value2 = "";
					$obj_checked = "";
					$obj_tag = "input";
					$obj_closing_tag = false;
					break;
					
				case "dropdown":
					$ret = cimy_dropDownOptions($label, $value);
					$label = $ret['label'];
					$html = $ret['html'];
					
					$obj_label = '<label for="'.$fields_name_prefix.$field_id.'">'.$label.'</label><br />';
					$obj_class = ' class="input"';
					$obj_name = ' name="'.$fields_name_prefix.$name.'"';
					$obj_type = '';
					$obj_value = '';
					$obj_value2 = $html;
					$obj_checked = "";
					$obj_tag = "select";
					$obj_closing_tag = true;
					break;
					
				case "textarea":
					$obj_label = '<label for="'.$fields_name_prefix.$field_id.'">'.$label.'</label><br />';
					$obj_class = ' class="input"';
					$obj_name = ' name="'.$fields_name_prefix.$name.'"';
					$obj_type = "";
					$obj_value = "";
					$obj_value2 = $value;
					$obj_checked = "";
					$obj_tag = "textarea";
					$obj_closing_tag = true;
					break;
	
				case "checkbox":
					$obj_label = '<label for="'.$fields_name_prefix.$field_id.'">'.$label.'</label><br />';
					$obj_class = "";
					$obj_name = ' name="'.$fields_name_prefix.$name.'"';
					$obj_type = ' type="'.$type.'"';
					$obj_value = ' value="1"';
					$obj_value2 = "";
					$value == "1" ? $obj_checked = ' checked="checked"' : $obj_checked = '';
					$obj_tag = "input";
					$obj_closing_tag = false;
					break;
	
				case "radio":
					$obj_label = '<label for="'.$fields_name_prefix.$field_id.'"> '.$label.'</label><br />';
					$obj_class = "";
					$obj_name = ' name="'.$fields_name_prefix.$name.'"';
					$obj_type = ' type="'.$type.'"';
					$obj_value = ' value="'.$field_id.'"';
					$obj_value2 = "";
					$obj_tag = "input";
					$obj_closing_tag = false;

					if ($value == "") {
						if (isset($radio_checked[$name]))
							$obj_checked = '';
						else {
							$obj_checked.= ' checked="checked"';
							$radio_checked += array($name => true);
						}
					}
					else
						intval($value) == intval($field_id) ? $obj_checked.= ' checked="checked"' : $obj_checked = '';

					break;
			}

			$obj_id = ' id="'.$fields_name_prefix.$field_id.'"';
			$obj_tabindex = ' tabindex="'.strval($tabindex).'"';
			$tabindex++;

			$obj_maxlen = "";

			if (in_array($type, $rule_maxlen_needed)) {
				if (isset($rules['max_length'])) {
					$obj_maxlen = ' maxlength="'.$rules['max_length'].'"';
				} else if (isset($rules['exact_length'])) {
					$obj_maxlen = ' maxlength="'.$rules['exact_length'].'"';
				}
			}
			
			if ($type == "textarea")
				$obj_rowscols = ' rows="3" cols="25"';
			else
				$obj_rowscols = '';
	
			echo "\t";
			$form_object = '<'.$obj_tag.$obj_id.$obj_class.$obj_name.$obj_type.$obj_value.$obj_checked.$obj_maxlen.$obj_rowscols.$obj_tabindex;
			
			if ($obj_closing_tag)
				$form_object.= ">".$obj_value2."</".$obj_tag.">";
			else
				$form_object.= " />";

			if ($type != "radio")
				echo $obj_label;

			// write to the html the form object built
			echo $form_object;

			if ($type == "radio")
				echo $obj_label;

			echo "\n\t</p>\n";
		}
	}

	echo $end_cimy_uef_comment;
}

function cimy_save_options() {
	global $cimy_uef_version, $cimy_uef_options, $max_length_fieldset_value;

	if (!current_user_can('level_10'))
		return;
	
	include("magic_quotes_gpc_off.php");
	
	$options = array();

	$options['version'] = $cimy_uef_version;
	$options['aue_hidden_fields'] = array();
	
	$items_per_fieldset = intval($_POST['items_per_fieldset']);
	
	if ($items_per_fieldset > 0)
		$options['items_per_fieldset'] = $items_per_fieldset;
	else
		$options['items_per_fieldset'] = 1;
	
	$options['fieldset_title'] = $_POST['fieldset_title'];	
	$options['fieldset_title'] = substr($options['fieldset_title'], 0, $max_length_fieldset_value);
	$options['fieldset_title'] = mysql_real_escape_string(htmlentities($options['fieldset_title'], ENT_QUOTES, "UTF-8"));

	
	if (isset($_POST['disable_cimy_fieldvalue']))
		$options['disable_cimy_fieldvalue'] = true;
	else
		$options['disable_cimy_fieldvalue'] = false;

	if (isset($_POST['hide_username']))
		array_push($options['aue_hidden_fields'], 'username');

	if (isset($_POST['hide_name']))
		array_push($options['aue_hidden_fields'], 'name');

	if (isset($_POST['hide_posts']))
		array_push($options['aue_hidden_fields'], 'posts');
	
	if (isset($_POST['hide_email']))
		array_push($options['aue_hidden_fields'], 'email');
	
	if (isset($_POST['hide_website']))
		array_push($options['aue_hidden_fields'], 'website');
	
	if (isset($_POST['hide_actions']))
		array_push($options['aue_hidden_fields'], 'actions');

	update_option($cimy_uef_options, $options);
	
	$results = array();
	$results['results'] = "Options changed";
	
	return $results;
}

function cimy_show_options($results) {
	global $cimy_uef_options, $max_length_fieldset_value, $cimy_uef_name, $cimy_uef_url, $cimy_uef_version;

	if (!current_user_can('level_10'))
		return;
	
	$options = get_option($cimy_uef_options);
	
	$options['disable_cimy_fieldvalue'] ? $disable_cimy_fieldvalue = ' checked="checked"' : $disable_cimy_fieldvalue = '';
	
	in_array('username', $options['aue_hidden_fields']) ? $aue_hide_username = ' checked="checked"' : $aue_hide_username = '';
	in_array('name', $options['aue_hidden_fields']) ? $aue_hide_name = ' checked="checked"' : $aue_hide_name = '';
	in_array('email', $options['aue_hidden_fields']) ? $aue_hide_email = ' checked="checked"' : $aue_hide_email = '';
	in_array('website', $options['aue_hidden_fields']) ? $aue_hide_website = ' checked="checked"' : $aue_hide_website = '';
	in_array('posts', $options['aue_hidden_fields']) ? $aue_hide_posts = ' checked="checked"' : $aue_hide_posts = '';
	in_array('actions', $options['aue_hidden_fields']) ? $aue_hide_actions = ' checked="checked"' : $aue_hide_actions = '';
	
	?><div class="wrap" id="options">
	<h2>Options - <a href="#addfield">Add a new Field</a> - <a href="#extrafields">Extra Fields</a></h2><?php

	// print successes if there are some
	if (count($results) > 0) {
	?>
		<div class="updated">
		<h3>SUCCESSFUL</h3>
		<ul>
			<?php 
			foreach ($results as $result)
				echo "<li>".$result."</li>";
			?>
		</ul>
		<br />
		</div>
	<?php
	}

	?><form method="post" action="#options">
	<p class="submit"><input type="submit" name="Submit" value="<?php _e('Update Options &raquo;') ?>" /></p>
	<fieldset class="options">
	<legend>General</legend>
	<table class="optiontable">
		<tr>
			<th scope="row" width="60%">
				<strong><a href="<?php echo $cimy_uef_url; ?>"><?php echo $cimy_uef_name; ?></a></strong><?php
				if ($cimy_uef_version != $options['version']) {
					?><br /><h4>VERSIONS MISMATCH! This because you haven't de-activate and re-activate the plug-in after the update! This could give problems...</h4><?php
				}
				?>
			</th>
			<td width="40%">v<?php echo $options['version'];
				if ($cimy_uef_version != $options['version']) {
					?> (installed is v<?php echo $cimy_uef_version; ?>)<?php
				}
				?>
			</td>
		</tr>
		<tr>
			<th scope="row">Disable get_cimyFieldValue function<br />(leave disabled if you don't know what to do)</th>
			<td><input type="checkbox" name="disable_cimy_fieldvalue" value="1"<?php echo $disable_cimy_fieldvalue; ?> /></td>
		</tr>

	</table>
	</fieldset>

	<fieldset class="options">
	<legend>User Profile</legend>
	<table class="optiontable">
		<tr>
			<th scope="row" width="60%">Items per fieldset</th>
			<td width="40%"><input type="text" name="items_per_fieldset" value="<?php echo $options['items_per_fieldset']; ?>" size="3" maxlength="3" /></td>
		</tr>
		<tr>
			<th scope="row">Fieldset's titles, separates with comma<br />example: title1,title2,title3</th>
			<td><input type="text" name="fieldset_title" value="<?php echo stripslashes($options['fieldset_title']); ?>" size="35" maxlength="<?php echo $max_length_fieldset_value; ?>" /></td>
		</tr>

	</table>
	</fieldset>

	<fieldset class="options">
	<legend>Authors &amp; Users Extended</legend>
	<table class="optiontable">
		<tr>
			<th scope="row" width="60%">Hide username field</th>
			<td width="40%"><input type="checkbox" name="hide_username" value="1"<?php echo $aue_hide_username; ?> /></td>
		</tr>
		<tr>
			<th>Hide name field</th>
			<td><input type="checkbox" name="hide_name" value="1"<?php echo $aue_hide_name; ?> /></td>
		</tr>
		<tr>
			<th>Hide n. posts field</th>
			<td><input type="checkbox" name="hide_posts" value="1"<?php echo $aue_hide_posts; ?> /></td>
		</tr>

		<tr>
			<th scope="row">Hide email field</th>
			<td><input type="checkbox" name="hide_email" value="1"<?php echo $aue_hide_email; ?> /></td>
		</tr>
		<tr>
			<th scope="row">Hide website field</th>
			<td><input type="checkbox" name="hide_website" value="1"<?php echo $aue_hide_website; ?> /></td>
		</tr>
		<tr>
			<th scope="row">Hide actions</th>
			<td><input type="checkbox" name="hide_actions" value="1"<?php echo $aue_hide_actions; ?> /></td>
		</tr>
	</table>
	</fieldset>
	<input type="hidden" name="cimy_options" value="1" />
	<p class="submit"><input type="submit" name="Submit" value="<?php _e('Update Options &raquo;') ?>" /></p>
	</form>
	
	</div><?php
}

function cimy_admin_define_extra_fields() {
	global $wpdb, $wpdb_fields_table, $rule_canbeempty, $rule_email, $rule_maxlen, $rule_maxlen_needed, $available_types, $max_length_name, $max_length_label, $max_length_desc, $max_length_value, $rule_equalto_case_sensitive;
	
	if (!current_user_can('level_10'))
		return;
	
	include("magic_quotes_gpc_off.php");

	$minLen = 1;
	$maxLen = $max_length_value;

	$errors = Array();
	$results = Array();

	$sql = "SELECT id, COUNT(*) FROM ".$wpdb_fields_table." GROUP BY id";
	$num_fields = $wpdb->query($sql);

	$add_caption = "Add field";
	$edit_caption = "Update field";
	$del_caption = "Delete field";
	$delSel_caption = "Delete selected fields";
	$order_caption = "Change order";

	$submit = $_POST['submit'];

	$action = "";
	$field_order = "";

	if (isset($_POST['cimy_options'])) {
		$action = "options";
		$res = cimy_save_options();
	}
	else if (!stristr($submit, $add_caption) === false)
		$action = "add";
	else if (!stristr($submit, $edit_caption) === false)
		$action = "edit";
	else if (!stristr($submit, $del_caption) === false)
		$action = "del";
	else if (!stristr($submit, $delSel_caption) === false)
		$action = "delSel";
	else if (!stristr($submit, $order_caption) === false)
		$action = "order";

	// if pushed change order button
	if ($action == "order") {

		$sql = "UPDATE ".$wpdb_fields_table." SET F_ORDER=CASE F_ORDER";

		$k = (-1);
		$msg = "";
		$msg_new = "";
		$arr1 = Array();
		$arr2 = Array();

		// check which fields are selected
		for ($i = 1; $i <= $num_fields; $i++)
			if ($_POST['check'.$i]) {
				if ($k > (-1)) {
					$msg.= ", ";
					$msg_new.= ", ";
				}
				else
					$k = $i;

				$sql.= " WHEN ".$i." THEN ".$_POST['order'.$i];
				$msg.= $i;
				$msg_new.= $_POST['order'.$i];

				array_push($arr1, $i);
				array_push($arr2, $_POST['order'.$i]);
			}

		if ($k > (-1)) {
			if (count(array_diff($arr1, $arr2)) == 0) {
				$sql.= " ELSE F_ORDER END WHERE F_ORDER IN (".$msg.")";

				// $sql WILL BE: UPDATE <table> SET F_ORDER=CASE F_ORDER WHEN <oldvalue1> THEN <newvalue1> [WHEN ... THEN ...] ELSE F_ORDER END WHERE F_ORDER IN(<oldvalue1> [, <oldvalue2>... ])
				$wpdb->query($sql);

				$results['order'] = "Fields #".$msg." changed to #".$msg_new;
			}
			else
				$errors['order'] = "You cannot give an order that misses some numbers";
		}
		else
			$errors['order'] = "Nothing selected";
	}

	// if pushed delete or update single button
	if (($action == "del") || ($action == "edit")) {

		$from = strpos($submit, '#') + 1;
		$field_order = substr($submit, $from);

		// if pushed the single delete button then check the relative checkbox and let delSel code to delete it
		if ($action == "del") {
			$_POST['check'.$field_order] = 1;
			$action = "delSel";
		}
	}
	
	if ($action == "delSel") {

		$sql = "DELETE FROM ".$wpdb_fields_table." WHERE ";

		$k = (-1);
		$j = (-1);
		$msg = "";
		$not_del_old = "";
		$not_del_sql = "";

		// check which fields are selected for deletions
		for ($i = 1; $i <= $num_fields; $i++)
			if ($_POST['check'.$i]) {
				if ($k > (-1)) {
					$sql.= " OR ";
					$msg.= ", ";
				}
				else {
					$k = $i;
					$j = $i;
				}

				$sql.= "F_ORDER=".$i;
				$msg.= $i;
			}
			else // field to NOT be deleted, but order probably have to change, if j==(-1) then order is ok because deletions is after it!
				if ($j > (-1)) {
					if ($not_del_old != "") {
						
						$not_del_old.= ", ";
					}

					$not_del_sql.= " WHEN ".$i." THEN ".$j." ";
					$not_del_old.= $i;
					$j++;
				}

		// if at least one field was selected
		if ($k > (-1)) {
			// $sql WILL BE: DELETE FROM <table> WHERE F_ORDER=<value1> [OR F_ORDER=<value2> ...]
			$wpdb->query($sql);

			if ($not_del_sql != "") {
				$not_del_sql = "UPDATE ".$wpdb_fields_table." SET F_ORDER=CASE F_ORDER".$not_del_sql."ELSE F_ORDER END WHERE F_ORDER IN(".$not_del_old.")";

				// $not_del_sql WILL BE: UPDATE <table> SET F_ORDER=CASE F_ORDER WHEN <oldvalue1> THEN <newvalue1> [WHEN ... THEN ...] ELSE F_ORDER END WHERE F_ORDER IN(<oldvalue1> [, <oldvalue2>...])
				$wpdb->query($not_del_sql);
			}

			$results['delete'] = "Field(s) #".$msg." deleted correctly";
		}
		else
			$errors['delete'] = "Nothing selected";
	}

	if (($action == "add") || ($action == "edit")) {
		$store_rule = array();
		
		$name = substr($_POST['name'.$field_order], 0, $max_length_name);
		$value = substr($_POST['value'.$field_order], 0, $max_length_value);
		$desc = substr($_POST['description'.$field_order], 0, $max_length_desc);
		$label = substr($_POST['label'.$field_order], 0, $max_length_label);

		// RETRIEVE DATA FROM THE FORM
		$name = mysql_real_escape_string(htmlentities(strtoupper($name), ENT_QUOTES, "UTF-8"));
		$oldname = mysql_real_escape_string(htmlentities(strtoupper($_POST['oldname'.$field_order]), ENT_QUOTES, "UTF-8"));
		$value = mysql_real_escape_string(htmlentities($value, ENT_QUOTES, "UTF-8"));
		$desc = mysql_real_escape_string(htmlentities($desc, ENT_QUOTES, "UTF-8"));
		$label = mysql_real_escape_string(htmlentities($label, ENT_QUOTES, "UTF-8"));
		$type = $_POST['type'.$field_order];

		$minlen = $_POST['minlen'.$field_order];
		$exactlen = $_POST['exactlen'.$field_order];
		$maxlen = $_POST['maxlen'.$field_order];
		
		if ($minlen != "")
			$store_rule['min_length'] = intval(mysql_real_escape_string($_POST['minlength'.$field_order]));
		
		if ($exactlen != "")
			$store_rule['exact_length'] = intval(mysql_real_escape_string($_POST['exactlength'.$field_order]));

		if ($maxlen != "")
			$store_rule['max_length'] = intval(mysql_real_escape_string($_POST['maxlength'.$field_order]));
		
		$empty = $_POST['empty'.$field_order];
		$empty == "1" ? $store_rule['can_be_empty'] = true : $store_rule['can_be_empty'] = false;

		$store_rule['edit'] = $_POST['edit'.$field_order];
		
		$email = $_POST['email'.$field_order];
		$email == "1" ? $store_rule['email'] = true : $store_rule['email'] = false;
		$equal = $_POST['equal'.$field_order];
		
		if ($equal != "") {
			$store_rule['equal_to'] = mysql_real_escape_string(htmlentities($_POST['equalto'.$field_order], ENT_QUOTES, "UTF-8"));
			
			$equalto_casesens = $_POST['equalto_casesens'.$field_order];
		}
		
		$show_in_reg = $_POST['show_in_reg'.$field_order];
		$show_in_reg == "1" ? $store_rule['show_in_reg'] = true : $store_rule['show_in_reg'] = false;
		
		$show_in_profile = $_POST['show_in_profile'.$field_order];
		$show_in_profile == "1" ? $store_rule['show_in_profile'] = true : $store_rule['show_in_profile'] = false;
		
		$show_in_aeu = $_POST['show_in_aeu'.$field_order];
		$show_in_aeu == "1" ? $store_rule['show_in_aeu'] = true : $store_rule['show_in_aeu'] = false;

		// START CHECKING FOR ERRORS
		if ($name == "")
			$errors['name'] = "Name not specified";

		if ($label == "")
			$errors['label'] = "Label not specified";

		if (in_array($type, $rule_maxlen_needed)) {
			if ((($maxlen != "") || ($minlen != "")) && ($exactlen != ""))
				$errors['exactlength1'] = "If you select Exact length you cannot select Min or Max";
			else {
				if (($maxlen == "") && ($exactlen == ""))
					$errors['maxlength1'] = "Exact or Max length not selected (with this type is necessary)";
				
				// MIN LEN
				if ($minlen != "") {
					if (!isset($store_rule['min_length']))
						$errors['minlength2'] = "Min length not specified";
					else if (($store_rule['min_length'] < $minLen) || ($store_rule['min_length'] > $maxLen))
						$errors['minlength3'] = "Min length should be in the range of ".$minLen. "-".$maxLen;
				}
	
				// EXACT LEN
				if ($exactlen != "") {
					if (!isset($store_rule['exact_length']))
						$errors['exactlength2'] = "Exact length not specified";
					else if (($store_rule['exact_length'] < $minLen) || ($store_rule['exact_length'] > $maxLen))
						$errors['exactlength3'] = "Exact length should be in the range of ".$minLen. "-".$maxLen;
				}
				
				// MAX LEN
				if ($maxlen != "") {
					if (!isset($store_rule['max_length']))
						$errors['maxlength2'] = "Max length not specified";
					else if (($store_rule['max_length'] < $minLen) || ($store_rule['max_length'] > $maxLen))
						$errors['maxlength3'] = "Max length should be in the range of ".$minLen. "-".$maxLen;
				}
			}
		}
		else
			$maxlen = "";

		if ($equal != "") {
			if (!isset($store_rule['equal_to']))
				$errors['equalTo'] = "Equal TO not specified";
			else if ($store_rule['equal_to'] == "")
				$errors['equalTo'] = "Equal TO not specified";
			else if ((strtoupper($store_rule['equal_to']) != "YES") && (strtoupper($store_rule['equal_to']) != "NO")) {
				if ($type == "checkbox")
					$errors['equalTo2'] = "With checkbox type Equal TO can only be: [Yes, No]";

				if ($type == "radio")
					$errors['equalTo2'] = "With radio type Equal TO can only be: [Yes, No]";
			}
			
			if (($equalto_casesens != "") && (in_array($type, $rule_equalto_case_sensitive)))
				$store_rule['equal_to_case_sensitive'] = true;
			else
				$store_rule['equal_to_case_sensitive'] = false;
		}

		if (($value != "") && (strtoupper($value) != "YES") && (strtoupper($value) != "NO")) {
			if ($type == "checkbox")
				$errors['value'] = "With checkbox type Value can only be: [Yes, No]";

			if ($type == "radio")
				$errors['value'] = "With radio type Value can only be: [Yes, No]";
		}

		// IF THERE ARE NO ERRORS THEN GO ON
		if (count($errors) == 0) {
			$exist = array();

			if ($type != "radio") {
				$sql1 = "SELECT id FROM ".$wpdb_fields_table." WHERE name='".$name."' LIMIT 1";
				$exist = $wpdb->get_row($sql1);
			}

			// SEARCH THE NAME IN THE DATABASE, GO ON ONLY IF DURING EDIT IT WAS THE SAME FIELD
			if ((count($exist) == 0) || (($action == "edit") && ($oldname == $name))) {
				
				// MIN LEN
				if (!in_array($type, $rule_maxlen))
					unset($store_rule['min_length']);

				// EXACT LEN
				if (!in_array($type, $rule_maxlen))
					unset($store_rule['exact_length']);

				// MAX LEN
				if (!in_array($type, $rule_maxlen))
					unset($store_rule['max_length']);
				
				if (!in_array($type, $rule_email))
					$store_rule['email'] = false;
				
				if (!in_array($type, $rule_canbeempty))
					$store_rule['can_be_empty'] = true;

				if (($type == "checkbox") || ($type == "radio"))
					$value = strtoupper($value);

				if ($action == "add")
					$sql2 = "INSERT INTO ".$wpdb_fields_table." ";
				else if ($action == "edit")
					$sql2 = "UPDATE ".$wpdb_fields_table." ";

				$sql2.= "SET name='".$name."', value='".$value."', description='".$desc."', label='".$label."', type='".$type."', rules='".serialize($store_rule)."'";

				if ($action == "add")
					$sql2.= ", f_order=".($num_fields + 1);
				else if ($action == "edit")
					$sql2.= " WHERE F_ORDER=".$field_order;

				$wpdb->query($sql2);

				if ($action == "add")
					$results['inserted'] = "Field inserted correctly";
				else if ($action == "edit")
					$results['edit'] = "Field #".$field_order." updated correctly";
			}
			else {
				$errors['namedup'] = "Name inserted is just in the database, change to another one";
			}
		}
	}
	
	// call options function
	cimy_show_options($res);
	
	// do NOT move this line, it's here because should shows also field just added to the database
	$allFields = get_cimyFields();
	
	?>

	<div class="wrap" id="addfield">
	<h2>Add a new Field</h2>

	<?php

	// print errors if there are some
	if (count($errors) > 0) {
	?>
		<div class="error">
		<h3>ERROR</h3>
		<ul>
			<?php 
			foreach ($errors as $error)
				echo "<li>".$error."</li>";
			?>
		</ul>
		<br />
		</div>
	<?php
	}
	?>

	<?php

	// print successes if there are some
	if (count($results) > 0) {
	?>
		<div class="updated">
		<h3>SUCCESSFUL</h3>
		<ul>
			<?php 
			foreach ($results as $result)
				echo "<li>".$result."</li>";
			?>
		</ul>
		<br />
		</div>
	<?php
	}
	
	if ($store_rule['min_length'] == 0)
		unset($store_rule['min_length']);
	
	if ($store_rule['exact_length'] == 0)
		unset($store_rule['exact_length']);

	if ($store_rule['max_length'] == 0)
		unset($store_rule['max_length']);
	
	if ($action == "add") {
		// CAN BE MODIFIED OR NOT
		$selected_input[$store_rule['edit']] = ' selected="selected"';

		// NAME
		if ($name != "")
			$selected_input["name"] = $name;
		else
			$selected_input["name"] = '';
	
		// LABEL
		if ($label != "")
			$selected_input["label"] = $label;
		else
			$selected_input["label"] = '';
		
		// VALUE
		if ($value != "")
			$selected_input["value"] = $value;
		else
			$selected_input["value"] = '';
		
		// DESCRIPTION
		if ($desc != "")
			$selected_input["desc"] = $desc;
		else
			$selected_input["desc"] = '';
		
		// TYPE
		if ($type != "")
			$selected_input[$type] = ' selected="selected"';
		else
			$selected_input["text"] = ' selected="selected"';
	
		// MIN LEN
		if ($minlen != "")
			$selected_input["minlen"] = ' checked="checked"';
		else
			$selected_input["minlen"] = '';
		
		if (isset($store_rule['min_length']))
			$selected_input["min_length"] = $store_rule['min_length'];
		else
			$selected_input["min_length"] = '';
		
		// EXACT LEN
		if ($exactlen != "")
			$selected_input["exactlen"] = ' checked="checked"';
		else
			$selected_input["exactlen"] = '';
		
		if (isset($store_rule['exact_length']))
			$selected_input["exact_length"] = $store_rule['exact_length'];
		else
			$selected_input["exact_length"] = '';

		// MAX LEN
		if ($maxlen != "")
			$selected_input["maxlen"] = ' checked="checked"';
		else
			$selected_input["maxlen"] = '';
		
		if (isset($store_rule['max_length']))
			$selected_input["max_length"] = $store_rule['max_length'];
		else
			$selected_input["max_length"] = '';
		
		// EQUAL TO
		if (isset($equal))
			$selected_input["equal"] = ' checked="checked"';
		else
			$selected_input["equal"] = '';
	
		if (isset($store_rule['equal_to']))
			$selected_input["equal_to"] = $store_rule['equal_to'];
		else
			$selected_input["equal_to"] = '';
		
		if (isset($equalto_casesens))
			$selected_input["equal_to_case_sensitive"] = ' checked="checked"';
		else
			$selected_input["equal_to_case_sensitive"] = '';

		// CHECK EMAIL SYNTAX
		if ($store_rule['email'] == true)
			$selected_input["email"] = ' checked="checked"';
		else
			$selected_input["email"] = '';
	}
	// action is not "add"
	else
		$selected_input["ok_edit"] = ' selected="selected"';

	// CAN BE EMPTY
	if (($store_rule['can_be_empty'] == true) || ($action != "add"))
		$selected_input["empty"] = ' checked="checked"';
	else
		$selected_input["empty"] = '';

	// SHOW IN REGISTRATION
	if ((!isset($store_rule['show_in_reg'])) || ($store_rule['show_in_reg'] == true) || ($action != "add"))
		$selected_input["show_in_reg"] = ' checked="checked"';
	else
		$selected_input["show_in_reg"] = '';
	
	// SHOW IN PROFILE
	if ((!isset($store_rule['show_in_profile'])) || ($store_rule['show_in_profile'] == true) || ($action != "add"))
		$selected_input["show_in_profile"] = ' checked="checked"';
	else
		$selected_input["show_in_profile"] = '';


	// SHOW IN AUTHORS AND USERS EXTENDED
	if ((!isset($store_rule['show_in_aeu'])) || ($store_rule['show_in_aeu'] == true) || ($action != "add"))
		$selected_input["show_in_aeu"] = ' checked="checked"';
	else
		$selected_input["show_in_aeu"] = '';
	?>
	
	<form method="post" action="#addfield">
		<p>To add a new field you have to choose a name, type and label; optional are value and description. Rules are applied during user registration.</p><ul><li>With radio and checkbox: 'Value' and 'equal TO' can only be 'Yes' or 'No' that means 'selected' or 'not selected'</li><li>With drop-down: you have to add all options into label for example: label/item1,item2,item3</li></ul><br />

		<table cellpadding="10">
		<thead align="center">
		<tr>
			<td><h3>Name - Value</h3></td>
			<td><h3>Type</h3></td>
			<td><h3>Label - Description</h3></td>
			<td><h3>Rules</h3></td>
			<td><h3>Actions</h3></td>
		</tr>
		</thead>
		<tbody>
		<tr>
		<td>
			<label><strong>Name</strong><br /><input name="name" type="text" value="<?php echo $selected_input["name"]; ?>" maxlength="<?php echo $max_length_name; ?>" /></label><br /><br />
			<label><strong>Value</strong><br /><textarea name="value" rows="2" cols="17"><?php echo $selected_input["value"]; ?></textarea></label>
			</td>
			<td>
			<label><strong>Type</strong><br />
			<select name="type">
			<?php
				foreach($available_types as $this_type) {
					echo '<option value="'.$this_type.'"'.$selected_input[$this_type].'>'.$this_type.'</option>';
					echo "\n";
					
					if (isset($selected_input[$this_type]))
						unset($selected_input[$this_type]);
				}
			?>
			</select>
			</label>
		</td>
		<td>
			<label><strong>Label</strong><br /><textarea name="label" rows="2" cols="18"><?php echo $selected_input["label"]; ?></textarea></label><br /><br />
			<label><strong>Description</strong><br /><textarea name="description" rows="4" cols="18"><?php echo $selected_input["desc"]; ?></textarea></label>
		</td>
		<td>
			<!-- MIN LENGTH -->
			<input type="checkbox" name="minlen" value="1"<?php echo $selected_input["minlen"]; ?> /> Min length (1-<?php echo $max_length_value; ?>): &nbsp;&nbsp;&nbsp;<input type="text" name="minlength" value="<?php echo $selected_input["min_length"]; ?>" maxlength="4" size="4" /><br />
			
			<!-- EXACT LENGTH -->
			<input type="checkbox" name="exactlen" value="1"<?php echo $selected_input["exactlen"]; ?> /> Exact length (1-<?php echo $max_length_value; ?>): <input type="text" name="exactlength" value="<?php echo $selected_input["exact_length"]; ?>" maxlength="4" size="4" /><br />

			<!-- MAX LENGTH -->
			<input type="checkbox" name="maxlen" value="1"<?php echo $selected_input["maxlen"]; ?> /> Max length (1-<?php echo $max_length_value; ?>): &nbsp;&nbsp;<input type="text" name="maxlength" value="<?php echo $selected_input["max_length"]; ?>" maxlength="4" size="4" /><br />
			
			<input type="checkbox" name="empty" value="1"<?php echo $selected_input["empty"]; ?> /> Can be empty<br />
			<input type="checkbox" name="email" value="1"<?php echo $selected_input["email"]; ?> /> Check for E-mail syntax<br />
			
			<select name="edit">
				<option value="ok_edit"<?php echo $selected_input["ok_edit"]; ?>>Can be modified</option>
				<option value="edit_only_if_empty"<?php echo $selected_input["edit_only_if_empty"]; ?>>Can be modified only if empty</option>
				<option value="no_edit"<?php echo $selected_input["no_edit"]; ?>>Cannot be modified</option>
			<?php
				if (isset($selected_input[$edit]))
					unset($selected_input[$edit]);
			?>
			</select>
			<br />
			<!-- EQUAL TO -->
			<input type="checkbox" name="equal" value="1"<?php echo $selected_input["equal"]; ?> /> Should be equal TO: <input type="text" name="equalto" maxlength="50" value="<?php echo $selected_input["equal_to"]; ?>"/><br />
			<!-- CASE SENSITIVE -->
			&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="equalto_casesens" value="1"<?php echo $selected_input["equal_to_case_sensitive"]; ?> /> Case sensitive<br />
			
			<!-- SHOW IN REGISTRATION -->
			<input type="checkbox" name="show_in_reg" value="1"<?php echo $selected_input["show_in_reg"]; ?> /> Show the field in the registration<br />
			
			<!-- SHOW IN PROFILE -->
			<input type="checkbox" name="show_in_profile" value="1"<?php echo $selected_input["show_in_profile"]; ?> /> Show the field in User's profile<br />
			
			<!-- SHOW IN A&U EXTENDED -->
			<input type="checkbox" name="show_in_aeu" value="1"<?php echo $selected_input["show_in_aeu"]; ?> /> Show the field in A&amp;U Extended menu<br />
			</td>
		<td align="center">
			<input name="reset" type="reset" value="Clear" /><br /><br />
			<input name="submit" type="submit" value="<?php echo $add_caption ?>" />
		</td>
		</tr>
		</tbody>
		</table>
		<br /><br />
	</form>

	</div>

	<div class="wrap" id="extrafields">
	<h2>Extra Fields</h2>

	<form method="post" action="#addfield">

	<?php

	if (count($allFields) == 0)
		echo "None!";
	else {
		?>
		
		<input name="submit" type="submit" value="<?php echo $order_caption ?>" />
		<input name="submit" type="submit" value="<?php echo $delSel_caption ?>" />
		<p></p>

		<table cellpadding="10">
		<thead align="center">
		<tr>
			<td><h3>Order</h3></td>
			<td><h3>Name - Value - Type</h3></td>
			<td><h3>Label - Description</h3></td>
			<td><h3>Rules</h3></td>
			<td><h3>Actions</h3></td>
		</tr>
		</thead>
		<tbody>
		<?php

		foreach ($allFields as $field) {

			$id = $field['ID'];
			$order = $field['F_ORDER'];
			$name = $field['NAME'];
			$value = $field['VALUE'];
			$desc = $field['DESCRIPTION'];
			$label = $field['LABEL'];
			$type = $field['TYPE'];
			$rules = $field['RULES'];
	
			$text = "";
			$checkbox = "";
			$radio = "";

			$dis_maxlength = "";
			$dis_canbeempty = "";
			$dis_checkemail = "";
			$dis_equalto = "";
			$dis_equalto_casesens = "";
			$dis_value = "";

			// disable rules for certain fields
			if (!in_array($type, $rule_maxlen))
				$dis_maxlength = ' disabled="disabled"';
			
			if (!in_array($type, $rule_email))
				$dis_checkemail = ' disabled="disabled"';
			
			if (!in_array($type, $rule_canbeempty))
				$dis_canbeempty = ' disabled="disabled"';

			if (!in_array($type, $rule_equalto_case_sensitive))
				$dis_equalto_casesens = ' disabled="disabled"';

			// set selected type for every field
			$selected_type[$type] = ' selected="selected"';
	
			// MIN LEN
			if (isset($rules['min_length'])) {
				$minlen = ' checked="checked"';
				$minLength = $rules['min_length'];
			}
			else {
				$minlen = "";
				$minLength = "";
			}
			
			// EXACT LEN
			if (isset($rules['exact_length'])) {
				$exactlen = ' checked="checked"';
				$exactLength = $rules['exact_length'];
			}
			else {
				$exactlen = "";
				$exactLength = "";
			}
			
			// MAX LEN
			if (isset($rules['max_length'])) {
				$maxlen = ' checked="checked"';
				$maxLength = $rules['max_length'];
			}
			else {
				$maxlen = "";
				$maxLength = "";
			}
	
			if ($rules['can_be_empty'])
				$emp = ' checked="checked"';
			else
				$emp = "";
	
			if ($rules['email'])
				$email = ' checked="checked"';
			else
				$email = "";
	
			if ($rules['edit'] == 'ok_edit')
				$okedit = ' selected="selected"';
			else
				$okedit = "";
	
			if ($rules['edit'] == 'edit_only_if_empty')
				$editonlyifempty = ' selected="selected"';
			else
				$editonlyifempty = "";
	
			if ($rules['edit'] == 'no_edit')
				$noedit = ' selected="selected"';
			else
				$noedit = "";
			
			if (isset($rules['equal_to'])) {
				$equal = ' checked="checked"';
				$equalTo = $rules['equal_to'];
				
				if ($rules['equal_to_case_sensitive'])
					$equalto_casesens = ' checked="checked"';
			}
			else {
				$equal = "";
				$equalTo = "";
				$equalto_casesens = "";
			}

			if ($rules['show_in_reg'])
				$show_in_reg = ' checked="checked"';
			else
				$show_in_reg = "";

			if ($rules['show_in_profile'])
				$show_in_profile = ' checked="checked"';
			else
				$show_in_profile = "";

			if ($rules['show_in_aeu'])
				$show_in_aeu = ' checked="checked"';
			else
				$show_in_aeu = "";

			?>
			
			<tr>
			<td align="center">
				<input name="check<?php echo $order ?>" type="checkbox" value="1" /><br /><br />
				<label><strong>Order</strong><br />
				<input name="order<?php echo $order ?>" type="text" value="<?php echo $order ?>" maxlength="4" size="3" /></label>
			</td>
			<td>
				<label><strong>Name</strong><br />
				<input name="name<?php echo $order ?>" type="text" value="<?php echo $name ?>" maxlength="<?php echo $max_length_name; ?>" /></label><br /><br />
				<input name="oldname<?php echo $order ?>" type="hidden" value="<?php echo $name ?>" />
				<label><strong>Value</strong><br />
				<textarea name="value<?php echo $order ?>" rows="2" cols="17"><?php echo $value; ?></textarea></label>
				<br /><br />
				<label><strong>Type</strong><br />
				<select name="type<?php echo $order ?>">
				<?php 
					foreach($available_types as $this_type) {
						echo '<option value="'.$this_type.'"'.$selected_type[$this_type].'>'.$this_type.'</option>';
						
						if (isset($selected_type[$this_type]))
							unset($selected_type[$this_type]);
						echo "\n";
					}
				?>
				</select>
				</label>
				</td>
				<td>
				<label><strong>Label</strong><br />
				<textarea name="label<?php echo $order ?>" rows="2" cols="18"><?php echo $label; ?></textarea>
				</label><br /><br />
				<label><strong>Description</strong><br />
				<textarea name="description<?php echo $order ?>" rows="4" cols="18"><?php echo $desc ?></textarea>
				</label>
				</td>
				<td>
				<!-- MIN LENGTH -->
				<input type="checkbox" name="minlen<?php echo $order ?>" value="1"<?php echo $minlen.$dis_maxlength ?> /> Min length (1-<?php echo $max_length_value; ?>): &nbsp;&nbsp;&nbsp;<input type="text" name="minlength<?php echo $order ?>" value="<?php echo $minLength ?>" maxlength="4" size="4"<?php echo $dis_maxlength ?> /><br />

				<!-- EXACT LENGTH -->
				<input type="checkbox" name="exactlen<?php echo $order ?>" value="1"<?php echo $exactlen.$dis_maxlength ?> /> Exact length (1-<?php echo $max_length_value; ?>): <input type="text" name="exactlength<?php echo $order ?>" value="<?php echo $exactLength ?>" maxlength="4" size="4"<?php echo $dis_maxlength ?> /><br />
				
				<!-- MAX LENGTH -->
				<input type="checkbox" name="maxlen<?php echo $order ?>" value="1"<?php echo $maxlen.$dis_maxlength ?> /> Max length (1-<?php echo $max_length_value; ?>): &nbsp;&nbsp;<input type="text" name="maxlength<?php echo $order ?>" value="<?php echo $maxLength ?>" maxlength="4" size="4"<?php echo $dis_maxlength ?> /><br />
				
				<input type="checkbox" name="empty<?php echo $order ?>" value="1"<?php echo $emp.$dis_canbeempty ?> /> Can be empty<br />
				<input type="checkbox" name="email<?php echo $order ?>" value="1"<?php echo $email.$dis_checkemail ?> /> Check for E-mail syntax<br />

				<select name="edit<?php echo $order ?>">
				<option value="ok_edit"<?php echo $okedit ?>>Can be modified</option>
				<option value="edit_only_if_empty"<?php echo $editonlyifempty ?>>Can be modified only if empty</option>
				<option value="no_edit"<?php echo $noedit ?>>Cannot be modified</option>
				</select>
				<br />
				
				<!-- EQUAL TO -->
				<input type="checkbox" name="equal<?php echo $order ?>" value="1"<?php echo $equal.$dis_equalto ?> /> Should be equal TO: <input type="text" name="equalto<?php echo $order ?>" maxlength="50" value="<?php echo $equalTo ?>"<?php echo $dis_equalto ?> /><br />
				<!-- CASE SENSITIVE -->
				&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="equalto_casesens<?php echo $order ?>" value="1"<?php echo $equalto_casesens.$dis_equalto_casesens; ?> /> Case sensitive<br />

				
				<!-- SHOW IN REGISTRATION -->
				<input type="checkbox" name="show_in_reg<?php echo $order ?>" value="1"<?php echo $show_in_reg ?> /> Show the field in the registration<br />
				
				<!-- SHOW IN PROFILE -->
				<input type="checkbox" name="show_in_profile<?php echo $order ?>" value="1"<?php echo $show_in_profile ?> /> Show the field in User's profile<br />
				
				<!-- SHOW IN A&U EXTENDED -->
				<input type="checkbox" name="show_in_aeu<?php echo $order ?>" value="1"<?php echo $show_in_aeu ?> /> Show the field in A&amp;U Extended menu<br />
				</td>
				<td align="center">
				<input name="reset" type="reset" value="Reset" /><br /><br />
				<input name="submit" type="submit" value="<?php echo $edit_caption." #".$order ?>" /><br /><br />
				<input name="submit" type="submit" value="<?php echo $del_caption." #".$order ?>" />
			</td>
			</tr>
			<tr>
			<td colspan="5" align="center">
				<hr />
			</td>
			</tr>
		<?php
		}
		?>
		</tbody>
		</table>
		<?php
	}

	?>
	</form>

	</div>

	<?php
}

function cimy_admin_users_list_page() {
	global $wpdb, $wp_roles, $wpdb_data_table, $admin_menu_new_row, $cimy_uef_options;

	if (!current_user_can('level_10'))
		return;
	
	$options = get_option($cimy_uef_options);
	
	$extra_fields = get_cimyFields();
	//$num_rows_table = count($admin_menu_new_row) + 1;

// FIXME: to modify in the future
$num_rows_table = 1;

	$userids = $wpdb->get_col("SELECT ID FROM $wpdb->users;");
	
	foreach ($userids as $userid) {
		$tmp_user = new WP_User($userid);
		$roles = $tmp_user->roles;
		$role = array_shift($roles);
		$roleclasses[$role][$tmp_user->user_login] = $tmp_user;
	}

	?>

	<div class="wrap">
	<h2>Authors &amp; Users Extended List</h2>
	<table cellpadding="3" cellspacing="3" width="100%">
	<?php
	foreach ($roleclasses as $role => $roleclass) {
		ksort($roleclass);
		?>

		<tr>
		<th colspan="8" align="left">
		<h3><?php echo $wp_roles->role_names[$role]; ?></h3>
		</th></tr>
	
		<tr class="thead">
		<th rowspan='<?php echo $num_rows_table?>'><?php _e('User ID') ?></th>

		<?php
		if (!in_array("username", $options['aue_hidden_fields'])) {
			_e("<th rowspan='".$num_rows_table."'>Username</th>");
		}

		if (!in_array("name", $options['aue_hidden_fields'])) {
			_e("<th rowspan='".$num_rows_table."'>Name</th>");
		}

		if (!in_array("email", $options['aue_hidden_fields'])) {
			_e("<th rowspan='".$num_rows_table."'>E-mail</th>");
		}

		if (!in_array("website", $options['aue_hidden_fields'])) {
			_e("<th rowspan='".$num_rows_table."'>Website</th>");
		}

		if (!in_array("posts", $options['aue_hidden_fields'])) {
			_e("<th rowspan='".$num_rows_table."'>Posts</th>");
		}

		if (!in_array("actions", $options['aue_hidden_fields'])) {
			_e("<th rowspan='".$num_rows_table."'>Actions</th>");
		}
		
		$i = 0;
		if (count($extra_fields) > 0)
			foreach ($extra_fields as $thisField) {
				$rules = $thisField['RULES'];
				if ($rules['show_in_aeu']) {
	
					if (in_array($i, $admin_menu_new_row)) {
						echo "</tr><tr>";
					}
					$i++;
					
					$label = $thisField['LABEL'];
					
					if ($thisField['TYPE'] == "dropdown") {
						$ret = cimy_dropDownOptions($label, $value);
						$label = $ret['label'];
					}
				
					echo "<th>".$label."</th>";
				}
			}
		?>
	
		</tr>
		<?php
		$style = '';

		foreach ($roleclass as $user_object) {
			$email = $user_object->user_email;
			$url = $user_object->user_url;
			$short_url = str_replace('http://', '', $url);
			$short_url = str_replace('www.', '', $short_url);
			if ('/' == substr($short_url, -1))
				$short_url = substr($short_url, 0, -1);
			if (strlen($short_url) > 35)
			$short_url =  substr($short_url, 0, 32).'...';
			$style = ('class="alternate"' == $style) ? '' : 'class="alternate"';
			$numposts = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_author = '$user_object->ID' and post_status = 'publish'");
			if (0 < $numposts) $numposts = "<a href='edit.php?author=$user_object->ID' title='" . __('View posts') . "'>$numposts</a>";
			echo "
			<tr $style>
			<td rowspan='".$num_rows_table."'><input type='checkbox' name='users[]' id='user_{$user_object->ID}' value='{$user_object->ID}' /> <label for='user_{$user_object->ID}'>{$user_object->ID}</label></td>";

			if (!in_array("username", $options['aue_hidden_fields'])) {
				echo "<td rowspan='".$num_rows_table."'><label for='user_{$user_object->ID}'><strong>$user_object->user_login</strong></label></td>";
			}

			if (!in_array("name", $options['aue_hidden_fields'])) {
				echo "<td rowspan='".$num_rows_table."'><label for='user_{$user_object->ID}'>$user_object->first_name $user_object->last_name</label></td>";
			}

			if (!in_array("email", $options['aue_hidden_fields'])) {
				echo "<td rowspan='".$num_rows_table."'><a href='mailto:$email' title='" . sprintf(__('e-mail: %s'), $email) . "'>$email</a></td>";
			}

			if (!in_array("website", $options['aue_hidden_fields'])) {
				echo "<td rowspan='".$num_rows_table."'><a href='$url' title='website: $url'>$short_url</a></td>";
			}

			if (!in_array("posts", $options['aue_hidden_fields'])) {
				echo "<td rowspan='".$num_rows_table."' align='right'>$numposts</td>";
			}

			if (!in_array("actions", $options['aue_hidden_fields'])) {
				echo "<td rowspan='".$num_rows_table."'>";
				if (current_user_can('edit_users'))
					echo "<a href='user-edit.php?user_id=$user_object->ID' class='edit'>".__('Edit')."</a>";
				echo '</td>';
			}

			// if user has not yet fields in the data table then create them
			if (count($extra_fields) > 0)
				foreach ($extra_fields as $thisField) {

					$field_id = $thisField['ID'];

					cimy_insert_ExtraFields_if_not_exist($user_object->ID, $field_id);
				}

			$ef_db = $wpdb->get_results("SELECT FIELD_ID, VALUE FROM ".$wpdb_data_table." WHERE USER_ID = ".$user_object->ID, ARRAY_A);

			$i = 0;
			// print all the content of extra fields if there are some
			if (count($extra_fields) > 0)
				foreach ($extra_fields as $thisField) {
				
					$rules = $thisField['RULES'];
					
					if ($rules['show_in_aeu']) {
						$field_id = $thisField['ID'];

						/*if (in_array($i, $admin_menu_new_row)) {
							echo "</tr><tr $style>";
						}*/

						foreach ($ef_db as $d_field)
							if ($d_field['FIELD_ID'] == $field_id)	
								$field = stripslashes($d_field['VALUE']);
						
						echo "<td>".$field;
						
						//if ($i == 0 || in_array($i, $admin_menu_new_row))
						echo "&nbsp;"."</td>";
					}
				$i++;
				}
			echo '</tr>';
		}
	}

	?>
	</table>
	</div>

	<?php
}

function cimy_plugin_uninstall() {
	global $wpdb, $wpdb_data_table, $wpdb_fields_table;

	if (!current_user_can('activate_plugins'))
		return;

	$sql = "DROP TABLE ".$wpdb_data_table;
	$wpdb->query($sql);

	$sql = "DROP TABLE ".$wpdb_fields_table;
	$wpdb->query($sql);
}

function cimy_plugin_install () {
	global $wpdb, $wpdb_data_table, $wpdb_fields_table, $cimy_uef_options, $cimy_uef_options_descr, $cimy_uef_version;

	if (!current_user_can('activate_plugins'))
		return;
	
	if (!($options = get_option($cimy_uef_options))) {
		$options = array(
				'version' => $cimy_uef_version,
				'items_per_fieldset' => 5,
				'disable_cimy_fieldvalue' => true,
				'aue_hidden_fields' => array('website', 'posts', 'email'),
				'fieldset_title' => '',
				);
		
		add_option($cimy_uef_options, $options, $cimy_uef_options_descr, "no");
	} else {
		// switch without breaks so every earlier versions receive all updates
		switch ($options['version']) {
			case "0.9.1":
				$options['version'] = $cimy_uef_version;
				unset($options['show_buggy_ie_warning']);
			
			case "0.9.2":
				$options['version'] = $cimy_uef_version;
				
			case "0.9.3":
				$options['version'] = $cimy_uef_version;
		}
		
		update_option($cimy_uef_options, $options);
	}

	if ($wpdb->get_var("SHOW TABLES LIKE '$wpdb_data_table'") != $wpdb_data_table) {

		$sql = "CREATE TABLE ".$wpdb_data_table." (ID bigint(20) NOT NULL AUTO_INCREMENT, USER_ID bigint(20) NOT NULL, FIELD_ID bigint(20) NOT NULL, VALUE TEXT NOT NULL, PRIMARY KEY (ID), INDEX USER_ID (USER_ID), INDEX FIELD_ID (FIELD_ID))";

		require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
		dbDelta($sql);
	} else {
		$sql = "ALTER TABLE ".$wpdb_data_table." MODIFY VALUE TEXT";
		$wpdb->query($sql);
	}

	if ($wpdb->get_var("SHOW TABLES LIKE '$wpdb_fields_table'") != $wpdb_fields_table) {

		$sql = "CREATE TABLE ".$wpdb_fields_table." (ID bigint(20) NOT NULL AUTO_INCREMENT, F_ORDER bigint(20) NOT NULL, NAME varchar(20), LABEL TEXT, DESCRIPTION TEXT, TYPE varchar(20), RULES TEXT, VALUE TEXT, PRIMARY KEY (ID), INDEX F_ORDER (F_ORDER), INDEX NAME (NAME));";

		require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
		dbDelta($sql);
	} else {

		if ($wpdb->get_var("SHOW COLUMNS FROM $wpdb_fields_table LIKE 'VALUE'") != 'VALUE') {
			$sql = "ALTER TABLE ".$wpdb_fields_table." ADD VALUE TEXT";
			$wpdb->query($sql);
		}

		$sql = "ALTER TABLE ".$wpdb_fields_table." MODIFY RULES TEXT, MODIFY DESCRIPTION TEXT";
		$wpdb->query($sql);
		
		$sql = "SELECT RULES FROM ".$wpdb_fields_table." WHERE F_ORDER=1";
		$rules = $wpdb->get_var($sql);
		
		// check for 0.9.0-beta8 and below rules and transform them all with serialized data
		// add also primary key and indexes to both tables
		if (!unserialize($rules)) {
			
			$sql = "ALTER TABLE ".$wpdb_data_table." DROP INDEX id, ADD PRIMARY KEY (ID), ADD INDEX USER_ID (USER_ID), ADD INDEX FIELD_ID (FIELD_ID)";
			$wpdb->query($sql);
			
			$sql = "ALTER TABLE ".$wpdb_fields_table." DROP INDEX id, ADD PRIMARY KEY (ID), ADD INDEX F_ORDER (F_ORDER), ADD INDEX NAME (NAME), MODIFY LABEL TEXT";
			$wpdb->query($sql);
			

			$sql = "SELECT RULES FROM ".$wpdb_fields_table;
			$rules = $wpdb->get_col($sql);
			$sql_new_rules = "";
			$sql_old_rules = "";
			$first = true;
			
			foreach ($rules as $rule) {
				$new_params = array();
				
				if (!stristr($rule, 'maxlen') === false) {
					
					$from = strpos($rule, '([(') + 3;
					
					// cannot use strrpos with PHPs < 5.0 because they parse only characters and not strings in the second parameter!
					$len = strpos($rule, ')])') - $from;
					$maxLength = substr($rule, $from, $len);
					
					$new_params['max_length'] = $maxLength;
				}
		
				if (!stristr($rule, 'canbeempty') === false)
					$new_params['can_be_empty'] = true;
				else
					$new_params['can_be_empty'] = false;
		
				if (!stristr($rule, 'email') === false)
					$new_params['email'] = true;
				else
					$new_params['email'] = false;
		
				if (!stristr($rule, 'okedit') === false)
					$new_params['edit'] = 'ok_edit';
		
				if (!stristr($rule, 'editonlyifempty') === false)
					$new_params['edit'] = 'edit_only_if_empty';
		
				if (!stristr($rule, 'noedit') === false)
					$new_params['edit'] = 'no_edit';
		
				if (!stristr($rule, 'equal') === false) {
					$equal = ' checked="checked"';
					$from = strpos($rule, '[([') + 3;
					
					// cannot use strrpos with PHPs < 5.0 because they parse only characters and not strings in the second parameter!
					$len = strpos($rule, '])]') - $from;	
					$equalTo = substr($rule, $from, $len);
					
					$new_params['equal_to'] = $equalTo;
				}
	
				if (!stristr($rule, 'regprofile') === false)
					$new_params['show_in_reg'] = true;
				else
					$new_params['show_in_reg'] = false;
				
				// new parameters from 0.9.0rc1
				$new_params['show_in_aeu'] = true;
				$new_params['show_in_profile'] = true;
				
				$new_params = serialize($new_params);
				
				if (!$first)
					$sql_old_rules.= ", ";
				else
					$first = false;
				
				$sql_new_rules.= " WHEN '".$rule."' THEN '".$new_params."'";
				$sql_old_rules.= "'".$rule."'";
			}
			
			$sql = "UPDATE ".$wpdb_fields_table." SET RULES=CASE RULES".$sql_new_rules." ELSE RULES END WHERE RULES IN(".$sql_old_rules.")";

			// $sql WILL BE: UPDATE <table> SET RULES=CASE RULES WHEN <oldvalue1> THEN <newvalue1> [WHEN ... THEN ...] ELSE RULES END WHERE RULES IN(<oldvalue1> [, <oldvalue2>...])
			$wpdb->query($sql);
		}
	}
}

function cimy_extract_ExtraFields() {
	global $wpdb, $user_ID, $wpdb_data_table, $start_cimy_uef_comment, $end_cimy_uef_comment, $rule_profile_value, $cimy_uef_options, $rule_maxlen_needed, $fields_name_prefix;
	
	// if editing a different user (only admin)
	if (isset($_GET['user_id'])) {
		if (!current_user_can('edit_user', $get_user_id))
			return;
		
		$get_user_id = $_GET['user_id'];
	}
	//editin own profile
	else {
		if (!isset($user_ID))
			return;
		
		$get_user_id = $user_ID;
	}
	
	$options = get_option($cimy_uef_options);
	$extra_fields = get_cimyFields();

	if (!empty($extra_fields)) {

		echo $start_cimy_uef_comment;

		echo '<br clear="all" />';
		echo "\n";
		echo "<h2>Extra Fields</h2>\n";
		
		foreach ($extra_fields as $thisField) {
	
			$field_id = $thisField['ID'];
	
			cimy_insert_ExtraFields_if_not_exist($get_user_id, $field_id);
		}
	
		$ef_db = $wpdb->get_results("SELECT FIELD_ID, VALUE FROM ".$wpdb_data_table." WHERE USER_ID = ".$get_user_id, ARRAY_A);

		$radio_checked = array();

		$prev_type = "radio";
		
		$i = 0;
		$pos = 0;
		$num_fieldset = 0;
		
		if ($options['fieldset_title'] != "")
			$fieldset_titles = explode(',', $options['fieldset_title']);
		else
			$fieldset_titles = array();
		
		echo "<fieldset>\n";
		
		if (isset($fieldset_titles[$num_fieldset]))
			echo "<legend>".$fieldset_titles[$num_fieldset]."</legend>\n";
		
		foreach ($extra_fields as $thisField) {
	
			$field_id = $thisField['ID'];
			$name = $thisField['NAME'];
			$rules = $thisField['RULES'];
			$type = $thisField['TYPE'];
			$label = $thisField['LABEL'];
			$description = $thisField['DESCRIPTION'];
			
			if ($rules['show_in_profile']) {
	
				foreach ($ef_db as $d_field) {
					if ($d_field['FIELD_ID'] == $field_id)
						$value = stripslashes($d_field['VALUE']);
				}
	
				unset($wasempty);
				
				if (in_array($type, $rule_profile_value)) {
					if ($value == "") {
						$value = $thisField['VALUE'];
						$wasempty = true;
					}
				}

				if ($i == $options['items_per_fieldset']) {
					echo "</fieldset>\n";
					
					$num_fieldset++;

					if ($pos == 1) {
						echo '<br clear="all" />';
						echo "\n";
						
						$pos = 0;
					}
					else
						$pos = 1;
					
					echo "<fieldset>\n";
					
					if (isset($fieldset_titles[$num_fieldset]))
						echo "<legend>".$fieldset_titles[$num_fieldset]."</legend>\n";
					
					$i = 0;
				}
				
				$i++;

				if ($description != "") {
					echo "\t";
					echo '<p class="desc"><br />'.$description.'</p>';
					echo "\n";
				}
		
				echo "\t<p>\n\t";
	
				switch($type) {
					case 'password':
					case "text":
						$obj_label = '<label for="'.$fields_name_prefix.$field_id.'">'.$label.'</label><br />';
						$obj_name = ' name="'.$fields_name_prefix.$name.'"';
						$obj_type = ' type="'.$type.'"';
						$obj_value = ' value="'.$value.'"';
						$obj_value2 = "";
						$obj_checked = "";
						$obj_tag = "input";
						$obj_closing_tag = false;
						$obj_style = "";
						
						if (((!isset($wasempty)) && ($rules['edit'] == 'edit_only_if_empty')) || ($rules['edit'] == 'no_edit'))
							$obj_disabled = ' disabled="disabled"';
						else
							$obj_disabled = "";
							
						break;
						
					case "textarea":
						$obj_label = '<label for="'.$fields_name_prefix.$field_id.'">'.$label.'</label><br />';
						$obj_name = ' name="'.$fields_name_prefix.$name.'"';
						$obj_type = "";
						$obj_value = "";
						$obj_value2 = $value;
						$obj_checked = "";
						$obj_tag = "textarea";
						$obj_closing_tag = true;
						$obj_style = "";
						
						if (((!isset($wasempty)) && ($rules['edit'] == 'edit_only_if_empty')) || ($rules['edit'] == 'no_edit'))
							$obj_disabled = ' disabled="disabled"';
						else
							$obj_disabled = "";
	
						break;
						
					case "dropdown":
						$ret = cimy_dropDownOptions($label, $value);
						$label = $ret['label'];
						$html = $ret['html'];
						
						$obj_label = '<label for="'.$fields_name_prefix.$field_id.'">'.$label.'</label><br />';
						$obj_name = ' name="'.$fields_name_prefix.$name.'"';
						$obj_type = '';
						$obj_value = '';
						$obj_value2 = $html;
						$obj_checked = "";
						$obj_tag = "select";
						$obj_closing_tag = true;
						$obj_style = "";
					
						if ($rules['edit'] == 'no_edit')
							$obj_disabled = ' disabled="disabled"';
						else
							$obj_disabled = "";
						
						break;
						
					case "checkbox":
						$obj_label = '<label for="'.$fields_name_prefix.$field_id.'">'.$label.'</label><br />';
						$obj_name = ' name="'.$fields_name_prefix.$name.'"';
						$obj_type = ' type="'.$type.'"';
						$obj_value = ' value="1"';
						$obj_value2 = "";
						$value == "YES" ? $obj_checked = ' checked="checked"' : $obj_checked = '';
						$obj_tag = "input";
						$obj_closing_tag = false;
						$obj_style = ' style="width:auto; border:0; background:white;"';
						
						if ($rules['edit'] == 'no_edit')
							$obj_disabled = ' disabled="disabled"';
						else
							$obj_disabled = "";
	
						break;
		
					case "radio":
						$obj_label = '<label for="'.$fields_name_prefix.$field_id.'"> '.$label.'</label><br />';
						$obj_name = ' name="'.$fields_name_prefix.$name.'"';
						$obj_type = ' type="'.$type.'"';
						$obj_value = ' value="'.$field_id.'"';
						$obj_value2 = "";
						$obj_tag = "input";
						$obj_closing_tag = false;
						$obj_style = ' style="width:auto; border:0; background:white;"';
	
						if ($rules['edit'] == 'no_edit')
							$obj_disabled = ' disabled="disabled"';
						else
							$obj_disabled = "";
	
						if ($value == "")
							$obj_checked = '';
						else
							$obj_checked.= ' checked="checked"';
	
						break;
				}
	
				
				$obj_id = ' id="'.$fields_name_prefix.$field_id.'"';
				$obj_class = '';
	
				$obj_maxlen = "";
	
				if (in_array($type, $rule_maxlen_needed)) {
					if (isset($rules['max_length'])) {
						$obj_maxlen = ' maxlength="'.$rules['max_length'].'"';
					} else if (isset($rules['exact_length'])) {
						$obj_maxlen = ' maxlength="'.$rules['exact_length'].'"';
					}
				}
				
				if ($type == "textarea")
					$obj_rowscols = ' rows="3" cols="25"';
				else
					$obj_rowscols = '';
		
				echo "\t";
				$form_object = '<'.$obj_tag.$obj_id.$obj_class.$obj_name.$obj_type.$obj_value.$obj_checked.$obj_maxlen.$obj_rowscols.$obj_style.$obj_disabled;
				
				if ($obj_closing_tag)
					$form_object.= ">".$obj_value2."</".$obj_tag.">";
				else
					$form_object.= " />";
	
				if ($type != "radio")
					echo $obj_label;
	
				// write to the html the form object built
				echo $form_object;
	
				if ($type == "radio")
					echo $obj_label;
	
				echo "\n\t</p>\n";
	
				$prev_type = $type;
			}
		}
		
		echo '</fieldset>';
		
		echo $end_cimy_uef_comment;
	}
}

function cimy_update_ExtraFields() {
	global $wpdb, $wpdb_data_table, $user_ID, $max_length_value, $fields_name_prefix;

	// if editing a different user (only admin)
	if (isset($_POST['user_id'])) {
		if (!current_user_can('edit_user', $get_user_id))
			return;
		
		$get_user_id = $_POST['user_id'];
	}
	//editin own profile
	else {
		if (!isset($user_ID))
			return;

		$get_user_id = $user_ID;
	}

	include("magic_quotes_gpc_off.php");
	$extra_fields = get_cimyFields();

	$query = "UPDATE ".$wpdb_data_table." SET VALUE=CASE FIELD_ID";
	$i = 0;

	$field_ids = "";

	foreach ($extra_fields as $thisField) {

		$field_id = $thisField["ID"];
		$name = $thisField["NAME"];
		$type = $thisField["TYPE"];
		$label = $thisField["LABEL"];
		$rules = $thisField["RULES"];
		
		cimy_insert_ExtraFields_if_not_exist($get_user_id, $field_id);

		if (isset($_POST[$fields_name_prefix.$name])) {

			$field_value = $_POST[$fields_name_prefix.$name];
			
			if (isset($rules['max_length']))
				$field_value = substr($field_value, 0, $rules['max_length']);
			else
				$field_value = substr($field_value, 0, $max_length_value);

			$field_value = mysql_real_escape_string(htmlentities($field_value, ENT_QUOTES, "UTF-8"));
			
			if ($i > 0)
				$field_ids.= ", ";
			else
				$i = 1;

			$field_ids.= $field_id;

			$query.= " WHEN ".$field_id." THEN ";
	
			switch ($type) {
				case 'textarea':
				case 'dropdown':
				case 'password':
				case 'text':
					$value = "'".$field_value."'";
					break;

				case 'checkbox':
					$value = $field_value == '1' ? "'YES'" : "'NO'";
					break;

				case 'radio':
					$value = $field_value == $field_id ? "'selected'" : "''";
					break;
			}

			$query.= $value;
		}
		// when a checkbox is not selected then it isn't present in $_POST at all
		else {
			if ($type == 'checkbox') {
				$rules = $thisField['RULES'];

				// if can be editable then write NO
				// there is no way to understand if was YES or NO previously
				// without adding other hidden inputs so write always
				if ($rules['edit'] == "ok_edit") {
					if ($i > 0)
						$field_ids.= ", ";
					else
						$i = 1;
		
					$field_ids.= $field_id;
		
					$query.= " WHEN ".$field_id." THEN ";

					$query.= "'NO'";
				}
			}
		}
	}

	if ($i > 0) {
		$query.=" ELSE FIELD_ID END WHERE FIELD_ID IN(".$field_ids.") AND USER_ID = ".$get_user_id;

		// $query WILL BE: UPDATE <table> SET VALUE=CASE FIELD_ID WHEN <field_id1> THEN <value1> [WHEN ... THEN ...] ELSE FIELD_ID END WHERE FIELD_ID IN(<field_id1>, [<field_id2>...]) AND USER_ID=<user_id>
		$wpdb->query($query);
	}
}

function cimy_insert_ExtraFields_if_not_exist($user_id, $field_id) {
	global $wpdb, $wpdb_data_table;

	$sql = "SELECT ID FROM ".$wpdb_data_table." WHERE FIELD_ID=".$field_id." AND USER_ID=".$user_id;
	$exist = $wpdb->get_var($sql);

	if ($exist == NULL) {
		$sql = "INSERT INTO ".$wpdb_data_table." SET FIELD_ID=".$field_id.", USER_ID=".$user_id;
		$wpdb->query($sql);
	}
}

function get_cimyFieldValue($user_id, $field_name, $field_value=false) {
	global $wpdb, $wpdb_data_table, $wpdb_fields_table, $cimy_uef_options;
	
	$options = get_option($cimy_uef_options);

	if ($options['disable_cimy_fieldvalue'])
		return NULL;

	if ((!isset($user_id)) || (!isset($field_name)))
		return NULL;
	
	if ((!$user_id) && (!$field_name))
		return NULL;
	
	if ($field_name) {
		$field_name = mysql_real_escape_string(htmlentities($field_name, ENT_QUOTES, "UTF-8"));
		$field_name = strtoupper($field_name);
	}
	
	if ($field_value) {
		$field_value = mysql_real_escape_string(htmlentities($field_value, ENT_QUOTES, "UTF-8"));
		
		$sql_field_value = " AND data.VALUE='".$field_value."'";
	}
	else
		$sql_field_value = "";

	if ($user_id) {
		$user_id = intval($user_id);
		
		if (!$user_id)
			return NULL;
	}
	
	// FIELD_NAME and USER_ID provided
	if (($field_name) && ($user_id)) {
		/*
			$sql will be:
		
			SELECT	fields.LABEL,
				fields.TYPE,
				data.VALUE
		
			FROM 	<wp users table> as users,
				<uef data table> as data
		
			JOIN	<uef fields table> as fields
		
			ON	fields.id=data.field_id
		
			WHERE	fields.name=<field_name>
				AND data.USER_ID=<user_id>
				AND fields.TYPE!='password'
				AND (fields.TYPE!='radio' OR data.VALUE!='')
				[AND data.VALUE=<field_value>]
		*/
		$sql = "SELECT fields.LABEL, fields.TYPE, data.VALUE FROM ".$wpdb->users." as users, ".$wpdb_data_table." as data JOIN ".$wpdb_fields_table." as fields ON fields.id=data.field_id WHERE fields.name='".$field_name."' AND data.USER_ID=".$user_id." AND fields.TYPE!='password' AND (fields.TYPE!='radio' OR data.VALUE!='')".$sql_field_value;
	}
	
	// only USER_ID provided
	if ((!$field_name) && ($user_id)) {
		/*
			$sql will be:
		
			SELECT	fields.LABEL,
				fields.TYPE,
				fields.NAME,
				data.VALUE
		
			FROM 	<uef data table> as data
		
			JOIN	<uef fields table> as fields
		
			ON	fields.id=data.field_id
		
			WHERE	AND data.USER_ID=<user_id>
				AND fields.TYPE!='password'
				AND (fields.TYPE!='radio' OR data.VALUE!='')
				[AND data.VALUE=<field_value>]
		*/
		$sql = "SELECT fields.LABEL, fields.TYPE, fields.NAME, data.VALUE FROM ".$wpdb_data_table." as data JOIN ".$wpdb_fields_table." as fields ON fields.id=data.field_id WHERE data.USER_ID=".$user_id." AND fields.TYPE!='password' AND (fields.TYPE!='radio' OR data.VALUE!='')".$sql_field_value;
	}
	
	// only FIELD_NAME provided
	if (($field_name) && (!$user_id)) {
		/*
			$sql will be:
		
			SELECT	fields.LABEL,
				fields.TYPE,
				users.user_login,
				data.VALUE
		
			FROM 	<wp users table> as users,
				<uef data table> as data
		
			JOIN	<uef fields table> as fields
		
			ON	fields.id=data.field_id
		
			WHERE	fields.name=<field_name>
				AND data.USER_ID=users.ID
				AND fields.TYPE!='password'
				AND (fields.TYPE!='radio' OR data.VALUE!='')
				[AND data.VALUE=<field_value>]
		*/
		$sql = "SELECT fields.LABEL, fields.TYPE, users.user_login, data.VALUE FROM ".$wpdb->users." as users, ".$wpdb_data_table." as data JOIN ".$wpdb_fields_table." as fields ON fields.id=data.field_id WHERE fields.name='".$field_name."' AND users.ID=data.USER_ID AND fields.TYPE!='password' AND (fields.TYPE!='radio' OR data.VALUE!='')".$sql_field_value;
	}
	
	$field_data = $wpdb->get_results($sql, ARRAY_A);
	
	if (isset($field_data)) {
		if ($field_data != NULL)
			$field_data = stripslashes_deep($field_data);
	}
	else
		return NULL;
	
	$field_data = cimy_change_radio_labels($field_data);
			
	if (($field_name) && ($user_id))
		$field_data = $field_data[0]['VALUE'];
	

	return $field_data;
}

function cimy_change_radio_labels($field_data) {
	$i = 0;
	
	while ($i < count($field_data)) {
		if ($field_data[$i]['TYPE'] == "radio") {
			$field_data[$i]['VALUE'] = $field_data[$i]['LABEL'];
		}
		
		unset($field_data[$i]['LABEL']);
		unset($field_data[$i]['TYPE']);
		
		$i++;
	}
	
	return $field_data;
}

?>